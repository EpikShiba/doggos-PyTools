import requests 


messagecontent = input("Message: ")
webhook1 = input("Input Webhook: ")
username = input("custom username: ")

url = webhook1 


data = {
    "content" : messagecontent,
    "username" : username
}

while(True):
    result = requests.post(url, json = data)
    print("message sent!", (messagecontent))


