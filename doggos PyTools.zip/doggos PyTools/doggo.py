def run(runfile):
  with open(runfile,"r") as rnf:
    exec(rnf.read())


print("Welcome to Doggo's PyTools! Please select your option.")
print("[1] Webhook Spammer")
option = int(input("choose your option: "))

if option == (1):
  run("import_requests.py")
    


