Hello, this is how to setup doggo tools. Doggos tools uses python, so make sure you have python installed.

To install python, go to: https://www.python.org/downloads/ 
and click download.


next, you want to double click the doggosetup.bat file. This will open cmd prompt and sta, and install requests module. after
it installs the module, it will instantly open doggo.py (the main file)


if you dont trust the bat file, you can open cmd by yourself and write py -m pip install requests
this will do the same thing, but i suggest using doggosetup.bat to save you a few clicks.



P.S. In the next few versions, i promise the folder will look much cleaner! i will also make
the doggo.py an executable so that its easier to open, and you dont have to always find it in that messy folder!

